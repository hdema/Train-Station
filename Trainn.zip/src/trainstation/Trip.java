package trainstation;

import java.sql.SQLException;
import java.util.Date;

public class Trip {

    private int ID;
    private float Cost;
    private String Departure_City,
            Destination_City,
            Departure_Time,
            Arrival_Time;
    private int day, month, year;

    public Trip(int ID, float Cost, String Departure_City, String Destination_City, String Departure_Time, String Arrival_Time, int day, int month, int year) {
        this.ID = ID;
        this.Cost = Cost;
        this.Departure_City = Departure_City;
        this.Destination_City = Destination_City;
        this.Departure_Time = Departure_Time;
        this.Arrival_Time = Arrival_Time;
        this.day = day;
        this.month = month;
        this.year = year;  
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public float getCost() {
        return Cost;
    }

    public void setCost(float Cost) {
        this.Cost = Cost;
    }

    public String getDeparture_City() {
        return Departure_City;
    }

    public void setDeparture_City(String Departure_City) {
        this.Departure_City = Departure_City;
    }

    public String getDestination_City() {
        return Destination_City;
    }

    public void setDestination_City(String Destination_City) {
        this.Destination_City = Destination_City;
    }

    public String getDeparture_Time() {
        return Departure_Time;
    }

    public void setDeparture_Time(String Departure_Time) {
        this.Departure_Time = Departure_Time;
    }

    public String getArrival_Time() {
        return Arrival_Time;
    }

    public void setArrival_Time(String Arrival_Time) {
        this.Arrival_Time = Arrival_Time;
    }

    public String getDate_() {

        return year + "/" + month + "/" + day;
    }

    public  void SaveToDB(int idD, int idT) throws SQLException, ClassNotFoundException{
        DataBase.AddTrip(this);
        DataBase.AssignTrain_DriverToTrip(ID, idT, idD);
        
    }
    
    @Override
    public String toString() {
        return "Trip{" + "ID=" + ID + ", Cost=" + Cost + ", Departure_City=" + Departure_City + ", Destination_City=" + Destination_City + ", Departure_Time=" + Departure_Time + ", Arrival_Time=" + Arrival_Time + ", Date=" + getDate_() + "}\n";
    }

}
