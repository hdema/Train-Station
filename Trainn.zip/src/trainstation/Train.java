package trainstation;

import java.sql.SQLException;
import java.util.ArrayList;

public class Train {

    private int ID, numberOfSeats;
    private String code, classID;

    public Train(int ID, String classID, String code, int numberOfSeats) {
        this.ID = ID;
        this.classID = classID;
        this.numberOfSeats = numberOfSeats;
        this.code = code;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getClassID() {
        return classID;
    }

    public void setClassID(String classID) {
        this.classID = classID;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public static ArrayList<String> GetAllClassifications() throws SQLException, ClassNotFoundException {
        return DataBase.BrowsingClassOFTrains();
    }

    public static int GetIdByCode(String code) throws SQLException, ClassNotFoundException {
        return DataBase.GetIdOfTrainByCode(code);
    }

    public static ArrayList<String> GetAllCodeOfClassifications(String classification) throws SQLException, ClassNotFoundException {
        return DataBase.GetCodeOfTrainsByClass(classification);
    }

    public void SaveToDB() throws SQLException, ClassNotFoundException {
        DataBase.AddTrain(this);
    }

    @Override
    public String toString() {
        return "Train{" + "ID=" + ID + ", classID=" + classID + ", numberOfSeats=" + numberOfSeats + ", code=" + code + '}';
    }

}
