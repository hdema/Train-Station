package trainstation;

import java.sql.SQLException;

public class Passenger {

    private int id;
    private String firstName, middleName, lastName;
    private int dayDOB, monthDOB, yearDOB;
    private String nationalNumber;

    public Passenger(String firstName, String middleName, String lastName, int dayDOB, int monthDOB, int yearDOB, String nationalNumber) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.dayDOB = dayDOB;
        this.monthDOB = monthDOB;
        this.yearDOB = yearDOB;
        this.nationalNumber = nationalNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getDayDOB() {
        return dayDOB;
    }

    public void setDayDOB(int dayDOB) {
        this.dayDOB = dayDOB;
    }

    public int getMonthDOB() {
        return monthDOB;
    }

    public void setMonthDOB(int monthDOB) {
        this.monthDOB = monthDOB;
    }

    public int getYearDOB() {
        return yearDOB;
    }

    public void setYearDOB(int yearDOB) {
        this.yearDOB = yearDOB;
    }

    public String getNationalNumber() {
        return nationalNumber;
    }

    public void setNationalNumber(String nationalNumber) {
        this.nationalNumber = nationalNumber;
    }

    public String getDate_() {

        return yearDOB + "/" + monthDOB + "/" + dayDOB;
    }

    @Override
    public String toString() {
        return "Passenger{" + "id=" + id + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", DOB=" + getDate_() + ", nationalNumber=" + nationalNumber + '}';
    }

    public void SetIDFromDB() throws SQLException, ClassNotFoundException
    {
        DataBase.SetIDPassenger(this);
    }
    public boolean CheckingExicting() throws SQLException, ClassNotFoundException {
        return DataBase.CheckExictingPassenger(nationalNumber);
    }

    public void SaveToDB() throws SQLException, ClassNotFoundException {
        DataBase.AddPassenger(this);
    }

}
