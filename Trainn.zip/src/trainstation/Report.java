package trainstation;

import java.sql.SQLException;
import java.util.ArrayList;

public class Report {

    private int ID;
    private int userID;
    private int day, month, year;
    private String details;

    public Report(int ID, int userID, int day, int month, int year, String details) {
        this.ID = ID;
        this.userID = userID;
        this.day = day;
        this.month = month;
        this.year = year;
        this.details = details;
    }

    
    public Report(int userID, int day, int month, int year, String details) {
        this.userID = userID;
        this.day = day;
        this.month = month;
        this.year = year;
        this.details = details;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDate_() {

        return year + "/" + month + "/" + day;
    }

    @Override
    public String toString() {
        return "Report{" + "ID=" + ID + ", userID=" + userID + ", date=" + getDate_() + ", details= " + details + '}';
    }

    public static ArrayList<Report> GetAllReportFromDB() throws SQLException, ClassNotFoundException
    {
        return DataBase.BrowsingReports();
    }
            
}
