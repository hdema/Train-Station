package trainstation;

import java.sql.SQLException;
import java.util.ArrayList;

public class Driver {

    private int id;
    private String firstName, middleName, lastName;
    private int dayDOB, monthDOB, yearDOB;
    private float salary;

    public Driver(int id, String firstName, String middleName, String lastName, int dayDOB, int monthDOB, int yearDOB, float salary) {
        this.id = id;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.dayDOB = dayDOB;
        this.monthDOB = monthDOB;
        this.yearDOB = yearDOB;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getDayDOB() {
        return dayDOB;
    }

    public void setDayDOB(int dayDOB) {
        this.dayDOB = dayDOB;
    }

    public int getMonthDOB() {
        return monthDOB;
    }

    public void setMonthDOB(int monthDOB) {
        this.monthDOB = monthDOB;
    }

    public int getYearDOB() {
        return yearDOB;
    }

    public void setYearDOB(int yearDOB) {
        this.yearDOB = yearDOB;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
    
    public String getDate_() {
        
        return yearDOB + "/" + monthDOB + "/" +dayDOB ;
    }

    public void SaveToDB() throws SQLException, ClassNotFoundException
    {
        DataBase.AddDriver(this);
    }
    
    public static int GetIdByName(String Name) throws SQLException, ClassNotFoundException {
        return DataBase.GetIdOfDriverByName(Name);
    }
    public static ArrayList<String> GetAllDrivers() throws SQLException, ClassNotFoundException
    {
        return DataBase.GetNamesOfDrivers();
    }
    @Override
    public String toString() {
        return "Driver{" + "id=" + id + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", DOB=" +getDate_()+ ", salary=" + salary + '}';
    }
    
    
}
