package trainstation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public abstract class Human {

    private int id;
    private String password;
    private String email;
    private String role;
   private ArrayList<Report> createdReports;

    public Human(String password, String email, String role) {

        this.password = password;
        this.email = email;
        this.role = role;
        createdReports = new ArrayList<>();

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public static Human Login(String email, String password) throws SQLException, ClassNotFoundException {
        return DataBase.login(email, password);
    }

    public static Human SignUp(Human human) throws SQLException, ClassNotFoundException {
        human.setId(DataBase.CreateHuman(human.getEmail(), human.getPassword(), human.getRole()));
        return human;
    }

    public void UpdatePassword(String newPassword) throws SQLException, ClassNotFoundException {
        DataBase.UpdateUserPassword(id, newPassword);
    }

    public void CreateReport(String reportDetails) throws SQLException, ClassNotFoundException {

        Date d = new Date();
        Report report = new Report(id, d.getDate(), d.getMonth()+1, d.getYear()+1900, reportDetails);
        DataBase.AddReport(report);
    }

    @Override
    public String toString() {
        return "Human{" + "id=" + id + ", password=" + password + ", email=" + email + ", role=" + role + '}';
    }

}
