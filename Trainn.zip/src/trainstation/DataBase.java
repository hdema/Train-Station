package trainstation;

import java.sql.*;
import java.util.ArrayList;

public class DataBase {

    static Connection con;

    public static Human login(String email, String password) throws SQLException, ClassNotFoundException {
        Human h = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/train_Station", "root", "123456789");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select user.id, user_role.role from user, user_role where user.roleID = user_role.id "
                + "and user.email = '" + email + "' and user.password = '" + password + "'");
        if (rs.next()) {
            if (rs.getString(2).equalsIgnoreCase("user")) {
                h = new User(password, email, rs.getString(2));
                h.setId(rs.getInt(1));
            } else if (rs.getString(2).equalsIgnoreCase("admin")) {
                h = new Admin(password, email, rs.getString(2));
                h.setId(rs.getInt(1));
            } else {
                h = new Employee(password, email, rs.getString(2));
                h.setId(rs.getInt(1));
            }
        }
        return h;
    }

    public static int CreateHuman(String email, String password, String role) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select user_role.id from user_role where user_role.role = '" + role + "'");
        rs.next();

        String SQL = String.format("INSERT INTO user (email, password, roleid) VALUES('%s','%s','%s')", email, password, rs.getInt(1));
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    id = rss.getInt(1);
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return -1;
            }
        }
        return id;
    }

    public static Trip AddTrip(Trip trip) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = String.format("INSERT INTO Trip (Cost,Departure_City ,  Destination_City , Departure_Time ,   Arrival_Time ,   Date_ ) VALUES('%f','%s','%s','%s','%s','%s')", trip.getCost(), trip.getDeparture_City(), trip.getDestination_City(), trip.getDeparture_Time(), trip.getArrival_Time(), trip.getDate_());
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    trip.setID(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;
            }
        }
        return trip;
    }

    public static Train AddTrain(Train train) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select Train_Classification.id from Train_Classification where Train_Classification.Classification  = '" + train.getClassID() + "'");
        rs.next();

        String SQL = String.format("INSERT INTO Train (code ,number_Of_Seats ,ClassID ) VALUES('%s',%d,%d)", train.getCode(), train.getNumberOfSeats(), rs.getInt(1));
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    train.setID(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;

            }
        }
        return train;
    }

    public static Driver AddDriver(Driver driver) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = String.format("INSERT INTO Driver (First_Name ,Middle_Name ,  Last_Name , DOB , salary) VALUES('%s','%s','%s','%s',%f)", driver.getFirstName(), driver.getMiddleName(), driver.getLastName(), driver.getDate_(), driver.getSalary());
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    driver.setId(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;

            }
        }
        return driver;
    }

    public static Report AddReport(Report report) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = String.format("INSERT INTO Report (Date_ ,details  ,  UserID ) VALUES('%s','%s',%d)", report.getDate_(), report.getDetails(), report.getUserID());
        PreparedStatement pstmt = con.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    report.setID(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;

            }
        }
        return report;
    }

    public static boolean AssignTrain_DriverToTrip(int tripID, int trainID, int driverID) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from Train where id = " + trainID);
        if (!rs.next()) {
            return false;
        }
        rs = stmt.executeQuery("select *  from Trip where id = " + tripID);
        if (!rs.next()) {
            return false;
        }
        rs = stmt.executeQuery("select *  from Driver where id = " + driverID);
        if (!rs.next()) {
            return false;
        }

        String SQL = String.format("INSERT INTO Trip_Train (TrainID ,TripID,DriveID) VALUES(%d,%d,%d)", trainID, tripID, driverID);
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    return true;

                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());

            }
        }
        return false;

    }

    public static ArrayList<Driver> BrowsingDrivers() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from Driver ");
        ArrayList<Driver> drivers = new ArrayList<>();
        while (rs.next()) {
            drivers.add(new Driver(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), Date.valueOf(rs.getString(5)).getDate(), Date.valueOf(rs.getString(5)).getMonth() + 1, Date.valueOf(rs.getString(5)).getYear() + 1900, rs.getFloat(6)));
        }
        return drivers;
    }

    public static Passenger AddPassenger(Passenger passenger) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = String.format("INSERT INTO Passenger (First_Name ,Middle_Name ,  Last_Name , DOB , national_number) VALUES('%s','%s','%s','%s','%s')", passenger.getFirstName(), passenger.getMiddleName(), passenger.getLastName(), passenger.getDate_(), passenger.getNationalNumber());
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    passenger.setId(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;

            }
        }
        return passenger;
    }

    public static boolean CheckExictingPassenger(String nationalNumber) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select * from passenger where national_number ='" + nationalNumber + "'");

        return rs.next();
    }

    public static void SetIDPassenger(Passenger passenger) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select id from passenger where national_number ='" + passenger.getNationalNumber() + "'");

        if (rs.next()) {
            passenger.setId(rs.getInt(1));
        }
    }

    public static Ticket Booking(Ticket ticket) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = String.format("INSERT INTO Ticket (Date_ ,seat_Number ,trip_trainID ,PassengerID ,UserID ) VALUES('%s',%d,%d,%d,%d)", ticket.getDate_(), ticket.getSeatNumber(), ticket.gettrip_trainID(), ticket.getPassengerID(), ticket.getUserID());
        PreparedStatement pstmt = con.prepareStatement(SQL,
                Statement.RETURN_GENERATED_KEYS);

        int affectedRows = pstmt.executeUpdate();
        int id = -1;
        if (affectedRows > 0) {
            // get the ID back
            try (ResultSet rss = pstmt.getGeneratedKeys()) {
                if (rss.next()) {
                    ticket.setID(rss.getInt(1));
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                return null;
            }
        }
        return ticket;
    }

    public static int getTotalSeatsOfTrain(String code) throws SQLException, ClassNotFoundException {

        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");
        CallableStatement stmt = con.prepareCall("{CALL get_number_Of_Seats(?)}");
        stmt.setString(1, code);
        ResultSet rs = stmt.executeQuery();
        rs.next();
        return rs.getInt(1);
    }

    public static int getBookeedSeatsOfTrain_Trip(int trip_trainID) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select count(*) "
                + "from trip_train, ticket "
                + "where trip_train.ID = " + trip_trainID + " "
                + "and ticket.trip_trainID = trip_train.ID "
        );

        rs.next();
        return rs.getInt(1);
    }

    public static void CancelBooking(int id) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        String SQL = "delete from Ticket where id = ?";
        PreparedStatement preparedStmt = con.prepareStatement(SQL);
        preparedStmt.setInt(1, id);
        preparedStmt.execute();

    }

    public static ArrayList<Train> BrowsingTrains() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from train ");
        ArrayList<Train> trains = new ArrayList<>();
        while (rs.next()) {
            trains.add(new Train(rs.getInt(1), rs.getString(4), rs.getString(2), rs.getInt(3)));
        }
        return trains;
    }

    public static boolean CheckingExictingCodeTrains(String code) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from train where code like '" + code + "'");
        return rs.next();
    }

    public static ArrayList<String> BrowsingClassOFTrains() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select Classification  from train_classification ");
        ArrayList<String> Classification = new ArrayList<>();
        while (rs.next()) {
            Classification.add(rs.getString(1));
        }
        return Classification;
    }

    public static ArrayList<Report> BrowsingReports() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from report ");
        ArrayList<Report> reports = new ArrayList<>();
        while (rs.next()) {
            reports.add(new Report(rs.getInt(1), rs.getInt(4), Date.valueOf(rs.getString(2)).getDate(), Date.valueOf(rs.getString(2)).getMonth() + 1, Date.valueOf(rs.getString(2)).getYear() + 1900, rs.getString(3)));
        }
        return reports;
    }

    public static ArrayList<Object> BrowsingPreviousBookings(int userID) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select trip.Cost , trip.Departure_City , trip.Destination_City ,"
                + " trip.Departure_Time , trip.Arrival_Time  , trip.Date_  , train.code , Train_Classification.Classification , "
                + "ticket. seat_Number ,ticket.date_, passenger.National_Number , ticket.id, ticket.trip_trainID"
                + " from ticket  , train , trip , trip_train  , Train_Classification  , Passenger "
                + "where ticket.Trip_trainID = trip_train.id "
                + "and trip_train.TrainID = train.id "
                + "and train.ClassID = Train_Classification.id "
                + "and ticket.PassengerID  = Passenger.id "
                + "and trip_train.TripID = trip.id "
                + "and ticket.userid = " + userID
                + " order by ticket.date_  desc , ticket.id  desc");
        ArrayList<Object> bookings = new ArrayList<>();
        while (rs.next()) {
            Trip trip = new Trip(-1, rs.getFloat(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), Date.valueOf(rs.getString(6)).getDate(), Date.valueOf(rs.getString(6)).getMonth() + 1, Date.valueOf(rs.getString(6)).getYear() + 1900);
            Train train = new Train(-1, rs.getString(8), rs.getString(7), -1);
            Ticket ticket = new Ticket(rs.getInt(12), rs.getInt(9), rs.getInt(13), -1, userID, Date.valueOf(rs.getString(10)).getDate(), Date.valueOf(rs.getString(10)).getMonth() + 1, Date.valueOf(rs.getString(10)).getYear() + 1900);
            String passengerNationalNum = rs.getString(11);
            bookings.add(trip);
            bookings.add(train);
            bookings.add(ticket);
            bookings.add(passengerNationalNum);

        }
        return bookings;
    }

    public static ArrayList<Object> BrowsingPreviousTrips(String Destination_City, String Date_) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs;
        if (!Destination_City.isEmpty() && Date_.isEmpty()) {

            rs = stmt.executeQuery("select trip_train.id ,trip.Cost , trip.Departure_City , trip.Destination_City ,"
                    + " trip.Departure_Time , trip.Arrival_Time  , trip.Date_  , train.code , Train_Classification.Classification  "
                    + " from  train , trip , trip_train  , Train_Classification  "
                    + "where trip_train.TrainID = train.id "
                    + "and train.ClassID = Train_Classification.id "
                    + "and trip_train.TripID = trip.id "
                    + "and trip.Destination_City like '" + Destination_City + "'  order by trip.date_  desc, trip.id desc");

        } else if (Destination_City.isEmpty() && !Date_.isEmpty()) {

            rs = stmt.executeQuery("select trip_train.id ,trip.Cost , trip.Departure_City , trip.Destination_City, "
                    + " trip.Departure_Time , trip.Arrival_Time  , trip.Date_  , train.code , Train_Classification.Classification  "
                    + " from  train , trip , trip_train  , Train_Classification  "
                    + "where trip_train.TrainID = train.id "
                    + "and train.ClassID = Train_Classification.id "
                    + "and trip_train.TripID = trip.id "
                    + "and  trip.Date_ = '" + Date_ + "'  order by trip.date_  desc, trip.id desc");

        } else if ((!Destination_City.isEmpty() && !Date_.isEmpty())) {
            rs = stmt.executeQuery("select trip_train.id ,trip.Cost , trip.Departure_City , trip.Destination_City ,"
                    + " trip.Departure_Time , trip.Arrival_Time  , trip.Date_  , train.code , Train_Classification.Classification  "
                    + " from  train , trip , trip_train  , Train_Classification  "
                    + "where trip_train.TrainID = train.id "
                    + "and train.ClassID = Train_Classification.id "
                    + "and trip_train.TripID = trip.id "
                    + "and  trip.Date_ = '" + Date_ + "' and trip.Destination_City like '" + Destination_City + "'  order by trip.date_  desc, trip.id desc");

        } else {
            rs = stmt.executeQuery("select trip_train.id ,trip.Cost , trip.Departure_City , trip.Destination_City ,"
                    + " trip.Departure_Time , trip.Arrival_Time  , trip.Date_  , train.code , Train_Classification.Classification  "
                    + " from  train , trip , trip_train  , Train_Classification  "
                    + "where trip_train.TrainID = train.id "
                    + "and train.ClassID = Train_Classification.id "
                    + "and trip_train.TripID = trip.id "
                    + " order by trip.date_  desc, trip.id desc");

        }
        ArrayList<Object> trips = new ArrayList<>();

        while (rs.next()) {
            Trip trip = new Trip(-1, rs.getFloat(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), Date.valueOf(rs.getString(7)).getDate(), Date.valueOf(rs.getString(7)).getMonth() + 1, Date.valueOf(rs.getString(7)).getYear() + 1900);
            Train train = new Train(-1, rs.getString(9), rs.getString(8), -1);
            int Trip_tarinID = rs.getInt(1);
            trips.add(trip);
            trips.add(train);
            trips.add(Trip_tarinID);

        }
        return trips;
    }

    public static boolean CheckingExistingAccount(String email) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select *  from user where email like '" + email + "'");
        return rs.next();
    }

    public static void UpdateUserPassword(int id, String newPassword) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        CallableStatement stmt = con.prepareCall("{CALL update_password(?,?)}");
        stmt.setInt(1, id);
        stmt.setString(2, newPassword);
        stmt.executeQuery();
    }

    public static ArrayList<String> GetCodeOfTrainsByClass(String Classification) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select code  from train, Train_Classification "
                + "where Train_Classification.Classification like '" + Classification + "' "
                + "and Train_Classification.ID = train.classID");
        ArrayList<String> codes = new ArrayList<>();
        while (rs.next()) {
            codes.add(rs.getString(1));
        }
        return codes;

    }

    public static ArrayList<String> GetNamesOfDrivers() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select First_Name, Middle_Name , Last_Name  from Driver ");
        ArrayList<String> names = new ArrayList<>();
        while (rs.next()) {
            names.add(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
        }
        return names;

    }

    public static String PassengersWithTypeOfAge() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT \n"
                + "    *,\n"
                + "    CASE\n"
                + "        WHEN dob > '2004-01-01' THEN 'children'\n"
                + "        WHEN dob < '2004-01-01' THEN 'adult'\n"
                + "    END AS TypeOfAge\n"
                + "FROM\n"
                + "    passenger;");

        String infoString = "";
        while (rs.next()) {
            infoString += "name: " + rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3)
                    + ", date of birth: " + rs.getString(4) + ", national number: " + rs.getString(5)
                    + ", type of age: " + rs.getString(6) + "\n";
        }
        return infoString;
    }

    public static String UsersInfo() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT \n"
                + "    COUNT(user.id) AS 'total number of users',\n"
                + "    user_role.role AS 'role'\n"
                + "FROM\n"
                + "    user,\n"
                + "    user_role\n"
                + "WHERE\n"
                + "    user.RoleID = user_role.ID\n"
                + "GROUP BY role;");

        String infoString = "";
        while (rs.next()) {
            infoString += "total number of users: " + rs.getString(1)
                    + ", role: " + rs.getString(2) + "\n";
        }
        return infoString;
    }

    public static String DriversAndPassengersNames() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT \n"
                + "    'Driver' AS Type, First_name, Middle_name, last_name\n"
                + "FROM\n"
                + "    Driver \n"
                + "UNION SELECT \n"
                + "    'Passenger', First_name, Middle_name, last_name\n"
                + "FROM\n"
                + "    Passenger");

        String infoString = "";
        while (rs.next()) {
            infoString += "type: " + rs.getString(1)
                    + ", name: " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4) + "\n";
        }
        return infoString;
    }

    public static int GetIdOfTrainByCode(String code) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select id  from train where code like '" + code + "'");
        rs.next();
        return rs.getInt(1);
    }

    public static int GetIdOfDriverByName(String name) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Train_Station", "root", "123456789-");

        CallableStatement stmt = con.prepareCall("{? = call get_id_of_driver(?,?,?)}");
        String fN = name.split(" ")[0], mN = name.split(" ")[1], lN = name.split(" ")[2];
        stmt.registerOutParameter(1, Types.INTEGER);
        stmt.setString(2, fN);
        stmt.setString(3, mN);
        stmt.setString(4, lN);

        stmt.execute();

        return stmt.getInt(1);
    }

    public static String GetStatistics() throws SQLException, ClassNotFoundException {
        String users = UsersInfo();
        int numberOfTrains = DataBase.BrowsingTrains().size();
        int numberOfDriers = DataBase.BrowsingDrivers().size();

        String Passengers = PassengersWithTypeOfAge();
        String passengerAndDrivers = DriversAndPassengersNames();
        
        return "#users: \n"+ users
                +"\n#number of trains: "+numberOfTrains
                +"\n#number of Drivers: "+numberOfDriers
                +"\n#Passengers:\n"+Passengers
                +"\n#Passengers and drivers:\n"+passengerAndDrivers;

    }
}
