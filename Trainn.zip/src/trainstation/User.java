package trainstation;

import java.sql.SQLException;
import java.util.ArrayList;

public class User extends Human {

    public User(String password, String email, String role) {
        super(password, email, role);

    }

    public void Booking(Ticket ticket) throws SQLException, ClassNotFoundException {
        DataBase.Booking(ticket);
    }

    public void RemoveBooking(int ticketID) throws ClassNotFoundException, SQLException {
        DataBase.CancelBooking(ticketID);
    }

    public ArrayList<Object> getBookings() throws ClassNotFoundException, SQLException {
        return DataBase.BrowsingPreviousBookings(super.getId());

    }

    public ArrayList<Object> getTrips(String D_C, String Date) throws SQLException, ClassNotFoundException {
        return DataBase.BrowsingPreviousTrips(D_C, Date);
    }
}
