package trainstation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class TrainStation extends Application {

    Human human;
    Scene LoginScene;  // login Scene
    Scene CreateAccountScene; //signup scene
    Scene UserOperationsScene; //user operations scene
    Scene EmployeeOperationsScene; // employee operaions scene
    Scene AdminOperationsScene; // admin operaions scene
    Scene PreviousUserBookingsScene; // previous user bookings scene
    Scene BrowsingNewTripsScene; // new trip scene
    Scene BookingScene; //booking scene
    Scene AdminCreateAccountScene; // create account by admin scene
    Scene ReportScene; // Report scene
    Scene DriverScene; // Driver scene
    Scene TrainScene; // Train scene    
    Scene TripScene; // Trip scene

    @Override
    public void start(Stage primaryStage) throws Exception {
        /////////////////////////////////////////////////////////////////////////////
        //------------------------------login scene------------------------------
        Label backGroundPhoto = new Label("", new ImageView(new Image("file:ts.png")));
        backGroundPhoto.setScaleX(0.5);
        backGroundPhoto.setScaleY(0.5);
        backGroundPhoto.setTranslateX(-150);
        backGroundPhoto.setTranslateY(-440);

        Label welcome = new Label("Welcome ");
        welcome.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        welcome.setTranslateX(40);
        welcome.setTranslateY(30);
        welcome.setTextFill(Paint.valueOf("Black"));

        Label emailLabel = new Label("Email");
        emailLabel.setFont(Font.font(15));

        Label userPasswordLabel = new Label("Password");
        userPasswordLabel.setFont(Font.font(15));

        TextField emailField = new TextField();
        TextField userPasswordField = new PasswordField();

        GridPane userInfo = new GridPane();
        userInfo.add(emailLabel, 0, 0);
        userInfo.add(userPasswordLabel, 0, 1);
        userInfo.add(emailField, 1, 0);
        userInfo.add(userPasswordField, 1, 1);
        userInfo.setTranslateX(40);
        userInfo.setTranslateY(110);
        userInfo.setHgap(50);
        userInfo.setVgap(15);

        Button loginBtn = new Button("Login");
        Button createAccountBtn = new Button("Create account");

        HBox logBtnBox = new HBox(loginBtn, createAccountBtn);
        logBtnBox.setSpacing(20);
        logBtnBox.setTranslateX(40);
        logBtnBox.setTranslateY(190);

        Label errLogin = new Label();
        errLogin.setTranslateX(40);
        errLogin.setTranslateY(225);
        errLogin.setTextFill(Paint.valueOf("Red"));
        errLogin.setVisible(false);

        Pane paneMenu = new Pane(backGroundPhoto, welcome, userInfo, logBtnBox, errLogin);        // conatiner of all containers in the scene
        LoginScene = new Scene(paneMenu, 800, 525);

        /////////////////////////////////////////////////////////////////////////////
        //------------------------------create account scene------------------------------
        Label CreateAnAccount = new Label("Create an account");
        CreateAnAccount.setFont(Font.font(null, FontWeight.BOLD, 30));

        CreateAnAccount.setTranslateX(40);
        CreateAnAccount.setTranslateY(30);

        Label EmailLabel = new Label("Email");
        EmailLabel.setFont(Font.font(15));
        TextField EmailField = new TextField();

        Label PasswordLabel = new Label("Password");
        PasswordLabel.setFont(Font.font(15));
        TextField PasswordField = new PasswordField();

        GridPane AccountInfo = new GridPane();

        AccountInfo.add(EmailLabel, 0, 2);
        AccountInfo.add(PasswordLabel, 0, 4);

        AccountInfo.add(EmailField, 1, 2);
        AccountInfo.add(PasswordField, 1, 4);

        AccountInfo.setTranslateX(75);
        AccountInfo.setTranslateY(125);
        AccountInfo.setHgap(60);
        AccountInfo.setVgap(15);

        Button CreateAccountBtn = new Button("Create account");
        CreateAccountBtn.setTranslateX(74);
        CreateAccountBtn.setTranslateY(275);

        Button backBtn = new Button("back");
        backBtn.setTranslateX(200);
        backBtn.setTranslateY(275);

        Label errCreation = new Label();
        errCreation.setTranslateX(75);
        errCreation.setTranslateY(310);
        errCreation.setTextFill(Paint.valueOf("Red"));

        Pane paneCreateAccount = new Pane(CreateAnAccount, AccountInfo, CreateAccountBtn, backBtn, errCreation);        // conatiner of all containers in the scene
        CreateAccountScene = new Scene(paneCreateAccount, 800, 525);

        //------------------------------user operations scene------------------------------
        Label backGroundPhoto1 = new Label("", new ImageView(new Image("file:ts.png")));
        backGroundPhoto1.setScaleX(0.5);
        backGroundPhoto1.setScaleY(0.5);
        backGroundPhoto1.setTranslateX(-150);
        backGroundPhoto1.setTranslateY(-440);

        Label userOprations = new Label("select.. ");
        userOprations.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        userOprations.setTranslateX(40);
        userOprations.setTranslateY(30);
        userOprations.setTextFill(Paint.valueOf("Black"));

        Button ShowPrviousBookingBtn = new Button("Show previous bookings");
        ShowPrviousBookingBtn.setTranslateX(60);
        ShowPrviousBookingBtn.setTranslateY(200);

        Button BrowsingNewTripsBtn = new Button("Browsing new trips");
        BrowsingNewTripsBtn.setTranslateX(60);
        BrowsingNewTripsBtn.setTranslateY(275);

        Button ReportAProblemeBtn = new Button("Report a problem ");
        ReportAProblemeBtn.setTranslateX(60);
        ReportAProblemeBtn.setTranslateY(350);

        Button EditPasswordBtn = new Button("Edit password");
        EditPasswordBtn.setTranslateX(60);
        EditPasswordBtn.setTranslateY(425);

        Pane paneUserMenu = new Pane(backGroundPhoto1, userOprations, ShowPrviousBookingBtn, BrowsingNewTripsBtn, ReportAProblemeBtn, EditPasswordBtn);        // conatiner of all containers in the scene
        UserOperationsScene = new Scene(paneUserMenu, 800, 525);
        //------------------------------employee operations scene------------------------------
        Label backGroundEmployee = new Label("", new ImageView(new Image("file:ts.png")));
        backGroundEmployee.setScaleX(0.5);
        backGroundEmployee.setScaleY(0.5);
        backGroundEmployee.setTranslateX(-150);
        backGroundEmployee.setTranslateY(-440);

        Label EmployeeOprations = new Label("select.. ");
        EmployeeOprations.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        EmployeeOprations.setTranslateX(40);
        EmployeeOprations.setTranslateY(30);
        EmployeeOprations.setTextFill(Paint.valueOf("Black"));

        Button AddANewTripBtn = new Button("Add a new trip");
        AddANewTripBtn.setTranslateX(60);
        AddANewTripBtn.setTranslateY(200);

        Button AddANewTrain = new Button("Add a new train");
        AddANewTrain.setTranslateX(60);
        AddANewTrain.setTranslateY(275);

        Button AddANewDriver = new Button("Add a new driver");
        AddANewDriver.setTranslateX(60);
        AddANewDriver.setTranslateY(350);

        Button employeePassword = new Button("Change password");
        employeePassword.setTranslateX(60);
        employeePassword.setTranslateY(425);

        Pane paneEmployeeMenu = new Pane(backGroundEmployee, EmployeeOprations, AddANewTripBtn, AddANewTrain, AddANewDriver, employeePassword);        // conatiner of all containers in the scene
        EmployeeOperationsScene = new Scene(paneEmployeeMenu, 800, 525);
        //------------------------------admin operations scene------------------------------
        Label backGroundAdmin = new Label("", new ImageView(new Image("file:ts.png")));
        backGroundAdmin.setScaleX(0.5);
        backGroundAdmin.setScaleY(0.5);
        backGroundAdmin.setTranslateX(-150);
        backGroundAdmin.setTranslateY(-440);

        Label AdminOprations = new Label("select.. ");
        AdminOprations.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        AdminOprations.setTranslateX(40);
        AdminOprations.setTranslateY(30);
        AdminOprations.setTextFill(Paint.valueOf("Black"));

        Button CreateUserBtn = new Button("Create a new user");
        CreateUserBtn.setTranslateX(60);
        CreateUserBtn.setTranslateY(200);

        Button ReviewReportsBtn = new Button("Review reports");
        ReviewReportsBtn.setTranslateX(60);
        ReviewReportsBtn.setTranslateY(275);

        Button AdminPWBtn = new Button("change password");
        AdminPWBtn.setTranslateX(60);
        AdminPWBtn.setTranslateY(350);

        Button StatisticsBtn = new Button("Statistics");
        StatisticsBtn.setTranslateX(60);
        StatisticsBtn.setTranslateY(425);

        Pane paneAdminMenu = new Pane(backGroundAdmin, AdminOprations, CreateUserBtn, ReviewReportsBtn, AdminPWBtn, StatisticsBtn);        // conatiner of all containers in the scene
        AdminOperationsScene = new Scene(paneAdminMenu, 800, 525);

        //------------------------------create account by admin----------------------------------
        Label SelectRole = new Label("select role");
        SelectRole.setFont(Font.font(15));
        RadioButton Admin = new RadioButton("Admin");
        RadioButton Employee = new RadioButton("Employee");
        ToggleGroup group = new ToggleGroup();
        Admin.setToggleGroup(group);
        Employee.setToggleGroup(group);
        HBox roleBox = new HBox(Admin, Employee);
        roleBox.setSpacing(20);
        VBox SelectRoleBox = new VBox(SelectRole, roleBox);
        SelectRoleBox.setTranslateX(75);
        SelectRoleBox.setTranslateY(100);

        Label EmailADLabel = new Label("Email");
        EmailADLabel.setFont(Font.font(15));
        TextField EmailADField = new TextField();

        Label PasswordADLabel = new Label("Password");
        PasswordADLabel.setFont(Font.font(15));
        TextField PasswordADField = new PasswordField();

        GridPane AccountADInfo = new GridPane();

        AccountADInfo.add(EmailADLabel, 0, 2);
        AccountADInfo.add(PasswordADLabel, 0, 4);

        AccountADInfo.add(EmailADField, 1, 2);
        AccountADInfo.add(PasswordADField, 1, 4);

        AccountADInfo.setTranslateX(75);
        AccountADInfo.setTranslateY(125);
        AccountADInfo.setHgap(60);
        AccountADInfo.setVgap(15);

        Button AdminCreateAccountBtn = new Button("Create account");
        AdminCreateAccountBtn.setTranslateX(74);
        AdminCreateAccountBtn.setTranslateY(275);

        Button AdminCreateAccountBackBtn = new Button("Back");
        AdminCreateAccountBackBtn.setTranslateX(200);
        AdminCreateAccountBackBtn.setTranslateY(275);

        Label CreateADAccount = new Label("Create an account");
        CreateADAccount.setFont(Font.font(null, FontWeight.BOLD, 30));

        CreateADAccount.setTranslateX(40);
        CreateADAccount.setTranslateY(30);

        Pane paneAdminCreateAccount = new Pane(CreateADAccount, AccountADInfo, SelectRoleBox, AdminCreateAccountBtn, AdminCreateAccountBackBtn, errCreation);        // conatiner of all containers in the scene
        AdminCreateAccountScene = new Scene(paneAdminCreateAccount, 800, 525);

        //------------------------------show previous booking scene------------------------------
        Label reportLabel = new Label("Reports: ");

        reportLabel.setFont(Font.font(20));
        reportLabel.setTranslateX(40);
        reportLabel.setTranslateY(30);

        ListView<Label> listViewReport = new ListView();
        listViewReport.setPrefSize(300, 425);
        listViewReport.setTranslateX(40);
        listViewReport.setTranslateY(75);

        Button backReport = new Button("Back");
        backReport.setTranslateX(750);
        backReport.setTranslateY(475);
        Pane ReportPane = new Pane(reportLabel, listViewReport, backReport);        // conatiner of all containers in the scene
        ReportScene = new Scene(ReportPane, 800, 525);
        //------------------------------show previous booking scene------------------------------
        Label RemovingNote = new Label("you can cancel booking while 3 days from booking date");

        RemovingNote.setFont(Font.font(20));
        RemovingNote.setTranslateX(40);
        RemovingNote.setTranslateY(30);

        ListView<Label> listView = new ListView();
        listView.setPrefSize(300, 425);
        listView.setTranslateX(40);
        listView.setTranslateY(75);

        Button cancelBookingButton = new Button("Cancel Booking");
        cancelBookingButton.setTranslateX(400);
        cancelBookingButton.setTranslateY(300);
        cancelBookingButton.setDisable(true);

        listView.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends Label> ov, Label old_val, Label new_val) -> {
                    if (new_val != null) {
                        Date newDate = new Date();
                        Date oldDate =new Date(new_val.getAccessibleText());
                        if (newDate.getYear()==oldDate.getYear() && newDate.getMonth()==oldDate.getMonth()
                                &&(newDate.getDate()==oldDate.getDate()||newDate.getDate()==oldDate.getDate()+1||newDate.getDate()==oldDate.getDate()+2||newDate.getDate()==oldDate.getDate()+3)) {
                            cancelBookingButton.setDisable(false);
                        } else {
                            cancelBookingButton.setDisable(true);
                        }
                    }
                });

        Button backCancelBooking = new Button("Back");
        backCancelBooking.setTranslateX(750);
        backCancelBooking.setTranslateY(475);
        Pane CancelBookingPane = new Pane(RemovingNote, cancelBookingButton, listView, backCancelBooking);        // conatiner of all containers in the scene
        PreviousUserBookingsScene = new Scene(CancelBookingPane, 800, 525);
        //------------------------------browsing new trips scene------------------------------
        ListView<Label> listViewTrips = new ListView();
        listViewTrips.setPrefSize(300, 425);
        listViewTrips.setTranslateX(40);
        listViewTrips.setTranslateY(75);

        Button bookingButton = new Button("Booking");
        bookingButton.setTranslateX(400);
        bookingButton.setTranslateY(300);
        bookingButton.setDisable(true);

        listViewTrips.getSelectionModel().selectedItemProperty().addListener(
                (ObservableValue<? extends Label> ov, Label old_val, Label new_val) -> {
                    if (new_val != null) {
                        try {
                            if (DataBase.getBookeedSeatsOfTrain_Trip(Integer.valueOf(new_val.getAccessibleHelp())) < DataBase.getTotalSeatsOfTrain(new_val.getAccessibleText())) {
                                bookingButton.setDisable(false);
                            }
                        } catch (SQLException ex) {
                            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                });

        Label CityLabel = new Label("Destination City");
        CityLabel.setFont(Font.font(15));
        TextField CityField = new TextField();

        Label DateLabel = new Label("Date");
        DateLabel.setFont(Font.font(15));
        TextField DateField = new TextField();
        DateField.setPromptText("YYYY-MM-DD");

        GridPane filters = new GridPane();

        filters.add(CityLabel, 0, 0);
        filters.add(CityField, 0, 1);

        filters.add(DateLabel, 1, 0);
        filters.add(DateField, 1, 1);

        filters.setTranslateX(40);
        filters.setTranslateY(10);
        filters.setHgap(60);
        filters.setVgap(5);

        Button filterBtn = new Button("Filter");
        filterBtn.setTranslateX(450);
        filterBtn.setTranslateY(22);

        Button ClearFilterBtn = new Button("Clear filter");
        ClearFilterBtn.setTranslateX(500);
        ClearFilterBtn.setTranslateY(22);

        Button backBooking = new Button("Back");
        backBooking.setTranslateX(750);
        backBooking.setTranslateY(475);
        Pane BookingPane = new Pane(bookingButton, listViewTrips, backBooking, filters, filterBtn, ClearFilterBtn);        // conatiner of all containers in the scene
        BrowsingNewTripsScene = new Scene(BookingPane, 800, 525);
        //------------------------------booking scene------------------------------

        Label bookATrip = new Label("Book your trip");
        bookATrip.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        bookATrip.setTranslateX(40);
        bookATrip.setTranslateY(30);
        bookATrip.setTextFill(Paint.valueOf("Black"));

        Label FNameLabel = new Label("First name");
        FNameLabel.setFont(Font.font(15));
        TextField FNameField = new TextField();

        Label MNameLabel = new Label("Middle name");
        MNameLabel.setFont(Font.font(15));
        TextField MNameField = new TextField();

        Label LNameLabel = new Label("Last name");
        LNameLabel.setFont(Font.font(15));
        TextField LNameField = new TextField();

        Label NationalNumberLabel = new Label("National number");
        NationalNumberLabel.setFont(Font.font(15));
        TextField NationalNumberField = new TextField();

        Label DateOfBirthLabel = new Label("Date Of Birth");
        DateOfBirthLabel.setFont(Font.font(15));
        DatePicker DateOfBirthPicker = new DatePicker();

        GridPane PassengerInfo = new GridPane();
        PassengerInfo.add(FNameLabel, 0, 0);
        PassengerInfo.add(MNameLabel, 0, 1);
        PassengerInfo.add(LNameLabel, 0, 2);
        PassengerInfo.add(NationalNumberLabel, 0, 3);
        PassengerInfo.add(DateOfBirthLabel, 0, 4);

        PassengerInfo.add(FNameField, 1, 0);
        PassengerInfo.add(MNameField, 1, 1);
        PassengerInfo.add(LNameField, 1, 2);
        PassengerInfo.add(NationalNumberField, 1, 3);
        PassengerInfo.add(DateOfBirthPicker, 1, 4);

        PassengerInfo.setTranslateX(75);
        PassengerInfo.setTranslateY(125);
        PassengerInfo.setHgap(60);
        PassengerInfo.setVgap(15);

        Button CompleteBtn = new Button("Complete");

        CompleteBtn.setTranslateX(75);
        CompleteBtn.setTranslateY(350);

        Label errComplete = new Label();
        errComplete.setTranslateX(175);
        errComplete.setTranslateY(350);
        errComplete.setTextFill(Paint.valueOf("Red"));
        Pane BookingTripPane = new Pane(bookATrip, PassengerInfo, CompleteBtn, errComplete);        // conatiner of all containers in the scene
        BookingScene = new Scene(BookingTripPane, 800, 525);

        //------------------------------add a new driver scene------------------------------
        Label newDriver = new Label("Add a new driver");
        newDriver.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        newDriver.setTranslateX(40);
        newDriver.setTranslateY(30);
        newDriver.setTextFill(Paint.valueOf("Black"));

        Label FNameDriverLabel = new Label("First name");
        FNameDriverLabel.setFont(Font.font(15));
        TextField FNameDriverField = new TextField();

        Label MNameDriverLabel = new Label("Middle name");
        MNameDriverLabel.setFont(Font.font(15));
        TextField MNameDriverField = new TextField();

        Label LNameDriverLabel = new Label("Last name");
        LNameDriverLabel.setFont(Font.font(15));
        TextField LNameDriverField = new TextField();

        Label SalaryLabel = new Label("Salary");
        SalaryLabel.setFont(Font.font(15));
        TextField SalaryField = new TextField();

        Label DateOfBirthDriverLabel = new Label("Date Of Birth");
        DateOfBirthDriverLabel.setFont(Font.font(15));
        DatePicker DateOfBirthDriverPicker = new DatePicker();

        GridPane DriverInfo = new GridPane();
        DriverInfo.add(FNameDriverLabel, 0, 0);
        DriverInfo.add(MNameDriverLabel, 0, 1);
        DriverInfo.add(LNameDriverLabel, 0, 2);
        DriverInfo.add(SalaryLabel, 0, 3);
        DriverInfo.add(DateOfBirthDriverLabel, 0, 4);

        DriverInfo.add(FNameDriverField, 1, 0);
        DriverInfo.add(MNameDriverField, 1, 1);
        DriverInfo.add(LNameDriverField, 1, 2);
        DriverInfo.add(SalaryField, 1, 3);
        DriverInfo.add(DateOfBirthDriverPicker, 1, 4);

        DriverInfo.setTranslateX(75);
        DriverInfo.setTranslateY(125);
        DriverInfo.setHgap(60);
        DriverInfo.setVgap(15);

        Button AddDriverBtn = new Button("Add");

        AddDriverBtn.setTranslateX(75);
        AddDriverBtn.setTranslateY(350);

        Label errDriver = new Label();
        errDriver.setTranslateX(175);
        errDriver.setTranslateY(350);
        errDriver.setTextFill(Paint.valueOf("Red"));
        Pane DriverPane = new Pane(newDriver, DriverInfo, AddDriverBtn, errDriver);        // conatiner of all containers in the scene
        DriverScene = new Scene(DriverPane, 800, 525);

        //------------------------------add a new train scene------------------------------
        Label newTrain = new Label("Add a new train");
        newTrain.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        newTrain.setTranslateX(40);
        newTrain.setTranslateY(30);
        newTrain.setTextFill(Paint.valueOf("Black"));

        Label ClassificationLabel = new Label("Classification");
        ClassificationLabel.setFont(Font.font(15));
        ComboBox ClassificationComboBox = new ComboBox();

        Label CodeLabel = new Label("Code");
        CodeLabel.setFont(Font.font(15));
        TextField CodeField = new TextField();

        Label NumOfSeatsLabel = new Label("Total number of seats");
        NumOfSeatsLabel.setFont(Font.font(15));
        TextField NumOfSeatsField = new TextField();

        GridPane TrainInfo = new GridPane();
        TrainInfo.add(ClassificationLabel, 0, 0);
        TrainInfo.add(CodeLabel, 0, 1);
        TrainInfo.add(NumOfSeatsLabel, 0, 2);

        TrainInfo.add(ClassificationComboBox, 1, 0);
        TrainInfo.add(CodeField, 1, 1);
        TrainInfo.add(NumOfSeatsField, 1, 2);

        TrainInfo.setTranslateX(75);
        TrainInfo.setTranslateY(125);
        TrainInfo.setHgap(60);
        TrainInfo.setVgap(15);

        Button AddTrainBtn = new Button("Add");

        AddTrainBtn.setTranslateX(75);
        AddTrainBtn.setTranslateY(250);

        Label errTrain = new Label();
        errTrain.setTranslateX(175);
        errTrain.setTranslateY(250);
        errTrain.setTextFill(Paint.valueOf("Red"));
        Pane TarinPane = new Pane(newTrain, TrainInfo, AddTrainBtn, errTrain);        // conatiner of all containers in the scene
        TrainScene = new Scene(TarinPane, 800, 525);

        //------------------------------add a new train scene------------------------------
        Label newTrip = new Label("Add a new trip");
        newTrip.setFont(Font.font("Castellar", FontWeight.BOLD, 60));
        newTrip.setTranslateX(40);
        newTrip.setTranslateY(30);
        newTrip.setTextFill(Paint.valueOf("Black"));

        Label ClassificationTLabel = new Label("Classification of train");
        ClassificationTLabel.setFont(Font.font(15));
        ComboBox ClassificationTComboBox = new ComboBox();

        Label TrainLabel = new Label("Code of train");
        TrainLabel.setFont(Font.font(15));
        ComboBox CodeComboBox = new ComboBox();
        CodeComboBox.setDisable(true);
        ClassificationTComboBox.getSelectionModel().selectedIndexProperty().addListener(
                (ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
                    CodeComboBox.setDisable(false);
                    try {
                        CodeComboBox.getItems().clear();
                        CodeComboBox.getItems().addAll(Train.GetAllCodeOfClassifications(ClassificationTComboBox.getSelectionModel().getSelectedItem().toString()));
                    } catch (SQLException ex) {
                        Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                });

        Label NameDriverLabel = new Label("Name Of Driver");
        NameDriverLabel.setFont(Font.font(15));
        ComboBox NameDriverBox = new ComboBox();

        Label CostLabel = new Label("Cost of trip");
        CostLabel.setFont(Font.font(15));
        TextField CostField = new TextField();

        Label Departure_CityLabel = new Label("Departure City");
        Departure_CityLabel.setFont(Font.font(15));
        TextField Departure_CityField = new TextField();

        Label Destination_CityLabel = new Label("Destination City");
        Destination_CityLabel.setFont(Font.font(15));
        TextField Destination_CityField = new TextField();

        Label DepTimeLabel = new Label("Departure Time");
        DepTimeLabel.setFont(Font.font(15));
        TextField DepTimeField = new TextField();

        Label ArrTimeLabel = new Label("Arrival Time");
        ArrTimeLabel.setFont(Font.font(15));
        TextField ArrTimeField = new TextField();

        Label DateOfTripLabel = new Label("Date Of Trip");
        DateOfTripLabel.setFont(Font.font(15));
        DatePicker DateOfTripDatePicker = new DatePicker();

        GridPane TripInfo = new GridPane();
        TripInfo.add(ClassificationTLabel, 0, 0);
        TripInfo.add(TrainLabel, 0, 1);
        TripInfo.add(NameDriverLabel, 0, 2);
        TripInfo.add(CostLabel, 0, 3);
        TripInfo.add(Departure_CityLabel, 0, 4);
        TripInfo.add(Destination_CityLabel, 0, 5);
        TripInfo.add(DepTimeLabel, 0, 6);
        TripInfo.add(ArrTimeLabel, 0, 7);
        TripInfo.add(DateOfTripLabel, 0, 8);

        TripInfo.add(ClassificationTComboBox, 1, 0);
        TripInfo.add(CodeComboBox, 1, 1);
        TripInfo.add(NameDriverBox, 1, 2);
        TripInfo.add(CostField, 1, 3);
        TripInfo.add(Departure_CityField, 1, 4);
        TripInfo.add(Destination_CityField, 1, 5);
        TripInfo.add(DepTimeField, 1, 6);
        TripInfo.add(ArrTimeField, 1, 7);
        TripInfo.add(DateOfTripDatePicker, 1, 8);

        TripInfo.setTranslateX(75);
        TripInfo.setTranslateY(125);
        TripInfo.setHgap(60);
        TripInfo.setVgap(15);

        Button AddTripBtn = new Button("Add");

        AddTripBtn.setTranslateX(575);
        AddTripBtn.setTranslateY(275);

        Label errTrip = new Label();
        errTrip.setTranslateX(575);
        errTrip.setTranslateY(300);
        errTrip.setTextFill(Paint.valueOf("Red"));
        Pane TripPane = new Pane(newTrip, TripInfo, AddTripBtn, errTrip);        // conatiner of all containers in the scene
        TripScene = new Scene(TripPane, 800, 525);

//
//        
//        
        /////////////////////////////////////////////////////////////////////////////
        //------------------------------Actions of buttons------------------------------
        StatisticsBtn.setOnAction(value -> {
            try {
                ScrollPane root = new ScrollPane();
                StackPane stackPane = new StackPane();

                stackPane.minWidthProperty().bind(Bindings.createDoubleBinding(()
                        -> root.getViewportBounds().getWidth(), root.viewportBoundsProperty()));
                stackPane.minHeightProperty().bind(Bindings.createDoubleBinding(()
                        -> root.getViewportBounds().getHeight(), root.viewportBoundsProperty()));
                Label statLabel = new Label(DataBase.GetStatistics());
                stackPane.getChildren().add(statLabel);
                root.setContent(stackPane);
                Scene s = new Scene(root, 700, 500);
                Stage stage = new Stage();
                stage.setScene(s);

                stage.show();
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddTripBtn.setOnAction(value -> {
            String Code = "", driver = "", Dep_city = "", Des_city = "", Dep_Time = "", Arr_Time = "", Date = "";
            float cost = 0;
            int numOfSeats = 0;

            if (ClassificationTComboBox.getSelectionModel().isEmpty()) {
                errTrip.setText("Choose class!");
            }

            if (CodeComboBox.getSelectionModel().isEmpty()) {
                errTrip.setText("Choose train!");
            } else {

                Code = CodeComboBox.getSelectionModel().getSelectedItem().toString();
            }

            if (NameDriverBox.getSelectionModel().isEmpty()) {
                errTrip.setText("select driver!");
            } else {
                driver = NameDriverBox.getSelectionModel().getSelectedItem().toString();
            }
            if (CostField.getText().isEmpty()) {
                errTrip.setText("insert cost!");

            } else {
                cost = Integer.valueOf(CostField.getText());
            }

            if (Departure_CityField.getText().isEmpty()) {
                errTrip.setText("insert departure city!");

            } else {
                Dep_city = Departure_CityField.getText();
            }
            if (Destination_CityField.getText().isEmpty()) {
                errTrip.setText("insert destination city!");

            } else {
                Des_city = Destination_CityField.getText();
            }
            if (DepTimeField.getText().isEmpty()) {
                errTrip.setText("insert departure time!");

            } else {
                Dep_Time = DepTimeField.getText();
            }
            if (ArrTimeField.getText().isEmpty()) {
                errTrip.setText("insert departure time!");

            } else {
                Arr_Time = ArrTimeField.getText();
            }

            if (DateOfTripDatePicker.getValue() == null) {
                errDriver.setText("choose your birthday!");

            } else {
                Date = DateOfTripDatePicker.getValue().toString();

            }
            // if the user has entered all wanted info
            if (!Date.isEmpty() && !Arr_Time.isEmpty() && !Dep_Time.isEmpty() && !Dep_city.isEmpty() && !Des_city.isEmpty() && !driver.isEmpty() && !Code.isEmpty() && cost != 0) {
                try {
                    Trip trip = new Trip(numOfSeats, cost, Dep_city, Des_city, Dep_Time, Arr_Time, Integer.valueOf(Date.split("-")[2]), Integer.valueOf(Date.split("-")[1]), Integer.valueOf(Date.split("-")[0]));
                    int driverID = Driver.GetIdByName(driver);
                    int trainID = Train.GetIdByCode(Code);
                    trip.SaveToDB(driverID, trainID);
                    Alert alertInformation = new Alert(AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Booking");
                    alertInformation.setContentText("new trip added successfully ..");
                    alertInformation.showAndWait();
                    primaryStage.setScene(EmployeeOperationsScene);
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
        createAccountBtn.setOnAction(e -> {
            EmailField.setText("");
            PasswordField.setText("");

            primaryStage.setScene(CreateAccountScene);

        });

        AdminCreateAccountBackBtn.setOnAction(value -> {
            primaryStage.setScene(AdminOperationsScene);

        });

        backBtn.setOnAction(value -> {
            primaryStage.setScene(LoginScene);

        });
        AdminCreateAccountBtn.setOnAction(e -> {
            String email = "", password = "", role = "";
            if (group.getSelectedToggle() != null) {
                role = ((RadioButton) group.getSelectedToggle()).getText();
            } else {
                errCreation.setText("Choose role!");
            }
            if (EmailADField.getText().isEmpty()) {
                errCreation.setText("insert email!");

            } else {
                try {
                    if (DataBase.CheckingExistingAccount(EmailADField.getText())) {
                        errCreation.setText("This email exist previously!");

                    } else {
                        email = EmailADField.getText();
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            if (PasswordADField.getText().isEmpty()) {
                errCreation.setText("insert password!");

            } else {
                password = PasswordADField.getText();

            }

            // if the user has entered all wanted info
            if (!email.isEmpty() && !password.isEmpty()) {
                human = new User(password, email, role);
                try {
                    Human.SignUp(human);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation registeration");
                    alertInformation.setContentText("You have just registerd..");
                    alertInformation.showAndWait();
                    primaryStage.setScene(AdminOperationsScene);

                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        CreateAccountBtn.setOnAction(e -> {
            String email = "", password = "";

            if (EmailField.getText().isEmpty()) {
                errCreation.setText("insert email!");

            } else {
                try {
                    if (DataBase.CheckingExistingAccount(EmailField.getText())) {
                        errCreation.setText("This email exist previously!");

                    } else {
                        email = EmailField.getText();
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

            if (PasswordField.getText().isEmpty()) {
                errCreation.setText("insert password!");

            } else {
                password = PasswordField.getText();

            }

            // if the user has entered all wanted info
            if (!email.isEmpty() && !password.isEmpty()) {
                human = new User(password, email, "user");
                try {
                    Human.SignUp(human);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation registeration");
                    alertInformation.setContentText("You have just registerd..");
                    alertInformation.showAndWait();
                    primaryStage.setScene(LoginScene);

                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        loginBtn.setOnAction(e -> {
            errLogin.setText("");
            if (emailField.getText().isEmpty()) { // if the user has not inserted any username

                errLogin.setText("email has not been insert!\n");
                errLogin.setVisible(true);

            }
            if (userPasswordField.getText().isEmpty()) { // if the user has not inserted any passwrd

                errLogin.setText(errLogin.getText() + "password has not been insert!");
                errLogin.setVisible(true);

            }
            if (!emailField.getText().isEmpty() && !userPasswordField.getText().isEmpty()) {
                try {
                    // if the user has entered username and password
                    human = Human.Login(emailField.getText(), userPasswordField.getText());
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (human == null) {
                    errLogin.setText("email or password incorrect!");
                    errLogin.setVisible(true);

                } else {
                    if (human instanceof User) {
                        primaryStage.setScene(UserOperationsScene);
                    } else if (human instanceof Employee) {
                        primaryStage.setScene(EmployeeOperationsScene);
                    } else if (human instanceof Admin) {
                        primaryStage.setScene(AdminOperationsScene);
                    }
                }
            }

        });

        ReportAProblemeBtn.setOnAction(value -> {
            String probleme = JOptionPane.showInputDialog("enter your probleme .");
            try {
                if (probleme != null) {
                    human.CreateReport(probleme);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation report");
                    alertInformation.setContentText("Thank you for your report..");
                    alertInformation.showAndWait();
                }

            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        AdminPWBtn.setOnAction(value
                -> {
            String newPassword = JOptionPane.showInputDialog("enter new password.");
            try {
                if (newPassword != null) {
                    human.UpdatePassword(newPassword);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Change");
                    alertInformation.setContentText("Your password has just changed correctly..");
                    alertInformation.showAndWait();
                }

            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        );
        employeePassword.setOnAction(value
                -> {
            String newPassword = JOptionPane.showInputDialog("enter new password.");
            try {
                if (newPassword != null) {
                    human.UpdatePassword(newPassword);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Change");
                    alertInformation.setContentText("Your password has just changed correctly..");
                    alertInformation.showAndWait();
                }

            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        );
        EditPasswordBtn.setOnAction(value
                -> {
            String newPassword = JOptionPane.showInputDialog("enter new password.");
            try {
                if (newPassword != null) {
                    human.UpdatePassword(newPassword);
                    Alert alertInformation = new Alert(Alert.AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Change");
                    alertInformation.setContentText("Your password has just changed correctly..");
                    alertInformation.showAndWait();
                }

            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        );

        ShowPrviousBookingBtn.setOnAction(value -> {
            ArrayList<Object> bs = new ArrayList<>();
            listView.getItems().clear();
            try {
                bs = ((User) human).getBookings();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0, j = 0; i < bs.size(); i += 4) {
                Trip trip = (Trip) bs.get(i);
                Train train = (Train) bs.get(i + 1);
                Ticket ticket = (Ticket) bs.get(i + 2);
                String passengerNationalNum = (String) bs.get(i + 3);
                Label l = new Label(++j + "#" + "Booking:"
                        + "\n\tCost of trip = " + trip.getCost()
                        + "\n\tDeparture City of trip = " + trip.getDeparture_City()
                        + "\n\tDestination City of trip= " + trip.getDestination_City()
                        + "\n\tDeparture Time of trip = " + trip.getDeparture_Time()
                        + "\n\tArrival Time  of trip = " + trip.getArrival_Time()
                        + "\n\tDate of trip = " + trip.getDate_()
                        + "\n\tCode of train = " + train.getCode()
                        + "\n\tClassification of train = " + train.getClassID()
                        + "\n\tSeat Number in train   = " + ticket.getSeatNumber()
                        + "\n\tDate of booking = " + ticket.getDate_()
                        + "\n\tNational number of passenger = " + passengerNationalNum
                );
                l.setWrapText(true);
                //ticket id
                l.setAccessibleHelp(String.valueOf(ticket.getID()));
                // ticket date
                l.setAccessibleText(String.valueOf(ticket.getDate_()));

                listView.getItems().add(l);
            }
            primaryStage.setScene(PreviousUserBookingsScene);
        });

        cancelBookingButton.setOnAction(value -> {
            try {
                int id = Integer.valueOf(listView.getSelectionModel().getSelectedItem().getAccessibleHelp());
                listView.getItems().remove(listView.getSelectionModel().getSelectedIndex());
                ((User) human).RemoveBooking(id);

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        backCancelBooking.setOnAction(value -> {
            primaryStage.setScene(UserOperationsScene);

        });

        backBooking.setOnAction(value -> {
            primaryStage.setScene(UserOperationsScene);
        });

        BrowsingNewTripsBtn.setOnAction(value -> {
            ArrayList<Object> ts = new ArrayList<>();
            listViewTrips.getItems().clear();
            try {
                ts = ((User) human).getTrips("", "");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0, j = 0; i < ts.size(); i += 3) {
                Trip trip = (Trip) ts.get(i);
                Train train = (Train) ts.get(i + 1);
                int Trip_tarinID = (int) ts.get(i + 2);
                Label l = new Label(++j + "#" + "Trip:"
                        + "\n\tCost of trip = " + trip.getCost()
                        + "\n\tDeparture City of trip = " + trip.getDeparture_City()
                        + "\n\tDestination City of trip= " + trip.getDestination_City()
                        + "\n\tDeparture Time of trip = " + trip.getDeparture_Time()
                        + "\n\tArrival Time  of trip = " + trip.getArrival_Time()
                        + "\n\tDate of trip = " + trip.getDate_()
                        + "\n\tCode of train = " + train.getCode()
                        + "\n\tClassification of train = " + train.getClassID()
                );
                l.setWrapText(true);
                //trip-train id
                l.setAccessibleHelp(String.valueOf(Trip_tarinID));
                //train code
                l.setAccessibleText(train.getCode());
                listViewTrips.getItems().add(l);
            }
            primaryStage.setScene(BrowsingNewTripsScene);
        });

        ClearFilterBtn.setOnAction(value -> {
            ArrayList<Object> ts = new ArrayList<>();
            listViewTrips.getItems().clear();
            CityField.setText("");
            DateField.setText("");
            try {
                ts = ((User) human).getTrips("", "");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0, j = 0; i < ts.size(); i += 3) {
                Trip trip = (Trip) ts.get(i);
                Train train = (Train) ts.get(i + 1);
                int Trip_tarinID = (int) ts.get(i + 2);
                Label l = new Label(++j + "#" + "Trip:"
                        + "\n\tCost of trip = " + trip.getCost()
                        + "\n\tDeparture City of trip = " + trip.getDeparture_City()
                        + "\n\tDestination City of trip= " + trip.getDestination_City()
                        + "\n\tDeparture Time of trip = " + trip.getDeparture_Time()
                        + "\n\tArrival Time  of trip = " + trip.getArrival_Time()
                        + "\n\tDate of trip = " + trip.getDate_()
                        + "\n\tCode of train = " + train.getCode()
                        + "\n\tClassification of train = " + train.getClassID()
                );
                l.setWrapText(true);
                //trip-train id
                l.setAccessibleHelp(String.valueOf(Trip_tarinID));
                //train code
                l.setAccessibleText(train.getCode());
                listViewTrips.getItems().add(l);
            }
        });

        filterBtn.setOnAction(value -> {
            ArrayList<Object> ts = new ArrayList<>();
            listViewTrips.getItems().clear();
            try {
                ts = ((User) human).getTrips(CityField.getText(), DateField.getText());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0, j = 0; i < ts.size(); i += 3) {
                Trip trip = (Trip) ts.get(i);
                Train train = (Train) ts.get(i + 1);
                int Trip_tarinID = (int) ts.get(i + 2);
                Label l = new Label(++j + "#" + "Trip:"
                        + "\n\tCost of trip = " + trip.getCost()
                        + "\n\tDeparture City of trip = " + trip.getDeparture_City()
                        + "\n\tDestination City of trip= " + trip.getDestination_City()
                        + "\n\tDeparture Time of trip = " + trip.getDeparture_Time()
                        + "\n\tArrival Time  of trip = " + trip.getArrival_Time()
                        + "\n\tDate of trip = " + trip.getDate_()
                        + "\n\tCode of train = " + train.getCode()
                        + "\n\tClassification of train = " + train.getClassID()
                );
                l.setWrapText(true);
                //trip-train id
                l.setAccessibleHelp(String.valueOf(Trip_tarinID));
                //train code
                l.setAccessibleText(train.getCode());
                listViewTrips.getItems().add(l);
            }
        });

        bookingButton.setOnAction(value -> {
            FNameField.setText("");
            LNameField.setText("");
            MNameField.setText("");
            NationalNumberField.setText("");
            DateOfBirthPicker.getEditor().clear();

            primaryStage.setScene(BookingScene);
        });

        CompleteBtn.setOnAction(e -> {
            String fname = "", lname = "", mname = "", nationalnumber = "", dateOFbirth = "";

            if (FNameField.getText().isEmpty()) {
                errCreation.setText("insert first name!");

            } else {
                fname = FNameField.getText();

            }
            if (LNameField.getText().isEmpty()) {
                errComplete.setText("insert last name!");

            } else {
                lname = LNameField.getText();

            }
            if (MNameField.getText().isEmpty()) {
                errComplete.setText("insert middle name!");

            } else {
                mname = MNameField.getText();

            }
            if (NationalNumberField.getText().isEmpty()) {
                errComplete.setText("insert national number!");

            } else {
                nationalnumber = NationalNumberField.getText();

            }

            if (DateOfBirthPicker.getValue() == null) {
                errComplete.setText("choose your birthday!");

            } else {
                dateOFbirth = DateOfBirthPicker.getValue().toString();

            }
            
            File myObj = new File("customer_details.txt");
            // if the user has entered all wanted info
            if (!fname.isEmpty() && !lname.isEmpty() && !mname.isEmpty() && !nationalnumber.isEmpty() && !dateOFbirth.isEmpty()) {
                try {
                    Passenger newPassenger = new Passenger(fname, mname, lname, Integer.valueOf(dateOFbirth.split("-")[2]), Integer.valueOf(dateOFbirth.split("-")[1]), Integer.valueOf(dateOFbirth.split("-")[0]), nationalnumber);

                    if (newPassenger.CheckingExicting()) {
                        newPassenger.SetIDFromDB();
                    } else {
                        newPassenger.SaveToDB();
                    }
                    Date today = new Date();
                    int trip_trainID = Integer.valueOf(listViewTrips.getSelectionModel().getSelectedItem().getAccessibleHelp());
                    Ticket newTicket = new Ticket(DataBase.getBookeedSeatsOfTrain_Trip(trip_trainID) + 1, trip_trainID, newPassenger.getId(), human.getId(), today.getDate(), today.getMonth() + 1, today.getYear() + 1900);
                    newTicket.SaveToDB();
                    Alert alertInformation = new Alert(AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Booking");
                    alertInformation.setContentText("You have just booked ..");
                    alertInformation.showAndWait();
                    try {
                        FileWriter myWriter = new FileWriter("customer_details.txt");
                        myWriter.write(fname+" "+lname+" "+mname+" "+nationalnumber+" "+dateOFbirth+"\n");
                        myWriter.close();
                    } 
                    catch (IOException exp) {
                        System.out.println("An error occurred.");
                        exp.printStackTrace();
                    }
                    primaryStage.setScene(BrowsingNewTripsScene);
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        AddDriverBtn.setOnAction(e -> {
            String fname = "", lname = "", mname = "", dateOFbirth = "";
            float salary = 0;

            if (FNameDriverField.getText().isEmpty()) {
                errDriver.setText("insert first name!");

            } else {
                fname = FNameDriverField.getText();

            }
            if (LNameDriverField.getText().isEmpty()) {
                errDriver.setText("insert last name!");

            } else {
                lname = LNameDriverField.getText();

            }
            if (MNameDriverField.getText().isEmpty()) {
                errDriver.setText("insert middle name!");

            } else {
                mname = MNameDriverField.getText();

            }
            if (SalaryField.getText().isEmpty()) {
                errDriver.setText("insert Salary!");

            } else {
                salary = Float.valueOf(SalaryField.getText());

            }

            if (DateOfBirthDriverPicker.getValue() == null) {
                errDriver.setText("choose your birthday!");

            } else {
                dateOFbirth = DateOfBirthDriverPicker.getValue().toString();

            }

            // if the user has entered all wanted info
            if (!fname.isEmpty() && !lname.isEmpty() && !mname.isEmpty() && salary != 0 && !dateOFbirth.isEmpty()) {
                try {
                    Driver driver = new Driver(0, fname, mname, lname, Integer.valueOf(dateOFbirth.split("-")[2]), Integer.valueOf(dateOFbirth.split("-")[1]), Integer.valueOf(dateOFbirth.split("-")[0]), salary);
                    driver.SaveToDB();
                    Alert alertInformation = new Alert(AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Booking");
                    alertInformation.setContentText("new driver added successfully ..");
                    alertInformation.showAndWait();
                    primaryStage.setScene(EmployeeOperationsScene);
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        AddANewDriver.setOnAction(value -> {
            Stage s = new Stage();

            s.setScene(DriverScene);
            s.show();
        });

        CreateUserBtn.setOnAction(value -> {
            EmailField.setText("");
            PasswordField.setText("");
            group.selectToggle(null);
            primaryStage.setScene(AdminCreateAccountScene);

        });

        AddTrainBtn.setOnAction(e -> {
            String Code = "", Class = "";
            int numOfSeats = 0;
            if (CodeField.getText().isEmpty()) {
                errTrain.setText("insert code of tarin!");
            } else {
                try {
                    if (DataBase.CheckingExictingCodeTrains(CodeField.getText())) {
                        errTrain.setText("Train with this code exists previously!");
                    } else {
                        Code = CodeField.getText();
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if (ClassificationComboBox.getSelectionModel().isEmpty()) {
                errTrain.setText("Choose class!");
            } else {
                Class = ClassificationComboBox.getSelectionModel().getSelectedItem().toString();
            }
            if (NumOfSeatsField.getText().isEmpty()) {
                errTrain.setText("insert total number of seats!");
            } else {
                numOfSeats = Integer.valueOf(NumOfSeatsField.getText());
            }

            // if the user has entered all wanted info
            if (!Class.isEmpty() && !Code.isEmpty() && numOfSeats != 0) {
                try {
                    Train train = new Train(0, Class, Code, numOfSeats);
                    train.SaveToDB();
                    Alert alertInformation = new Alert(AlertType.INFORMATION);
                    alertInformation.setTitle("Confirmation message");
                    alertInformation.setHeaderText("Confirmation Booking");
                    alertInformation.setContentText("new train added successfully ..");
                    alertInformation.showAndWait();
                    primaryStage.setScene(EmployeeOperationsScene);
                } catch (SQLException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });

        AddANewTrain.setOnAction(value -> {

            try {
                ClassificationComboBox.getItems().clear();
                CodeField.setText("");
                NumOfSeatsField.setText("");
                ClassificationComboBox.getItems().addAll(Train.GetAllClassifications());

                Stage s = new Stage();

                s.setScene(TrainScene);
                s.show();
            

        } catch (SQLException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }catch (ClassNotFoundException ex) {
                Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    );
        
    ReviewReportsBtn.setOnAction (value  
        -> {
            try {
            listViewReport.getItems().clear();
            ArrayList<Report> reports = Report.GetAllReportFromDB();
            for (int i = 0; i < reports.size(); i++) {
                Label l = new Label(i + 1 + "# Report:"
                        + "\n\tUser ID: " + reports.get(i).getID()
                        + "\n\tDate: " + reports.get(i).getDate_()
                        + "\n\tDetails: " + reports.get(i).getDetails());
                listViewReport.getItems().add(l);
            }
        } catch (SQLException ex) {
            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
        }
        primaryStage.setScene(ReportScene);

    }

    );
        
    AddANewTripBtn.setOnAction (value  
        -> {
            try {
            ClassificationTComboBox.getItems().clear();
            ClassificationTComboBox.getItems().addAll(Train.GetAllClassifications());
            NameDriverBox.getItems().clear();
            NameDriverBox.getItems().addAll(Driver.GetAllDrivers());
            Stage s = new Stage();
            
            s.setScene(TripScene);
            s.show();
        } catch (SQLException ex) {
            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TrainStation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    );
        
    backReport.setOnAction (v  
        -> {
            primaryStage.setScene(AdminOperationsScene);
    }

    );
        /////////////////////////////////////////////////////////////////////////////
        //------------------------------start the program------------------------------
    primaryStage.setTitle (
            

    "Train Station");
    primaryStage.setScene (LoginScene);

    primaryStage.show ();
}

public static void main(String[] args) throws SQLException, ClassNotFoundException {
        
        launch(args);
        
    }
    
}
