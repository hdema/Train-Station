/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainstation;

/**
 *
 * @author Lilas Al Araj
 */
public class Admin extends Human{
    
    public Admin( String password, String email, String role) {
        super( password, email, role);
    }
    
}
