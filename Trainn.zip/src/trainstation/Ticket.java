package trainstation;

import java.sql.SQLException;

public class Ticket {

    private int ID, seatNumber, trip_trainID, passengerID, userID, day, month, year;

    public Ticket(int ID, int seatNumber, int trip_trainID, int passengerID, int userID, int day, int month, int year) {
        this.ID = ID;
        this.seatNumber = seatNumber;
        this.trip_trainID = trip_trainID;
        this.passengerID = passengerID;
        this.userID = userID;
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public Ticket(int seatNumber, int trip_trainID, int passengerID, int userID, int day, int month, int year) {
        this.seatNumber = seatNumber;
        this.trip_trainID = trip_trainID;
        this.passengerID = passengerID;
        this.userID = userID;
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public int gettrip_trainID() {
        return trip_trainID;
    }

    public void settrip_trainID(int trip_trainID) {
        this.trip_trainID = trip_trainID;
    }

    public int getPassengerID() {
        return passengerID;
    }

    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDate_() {

        return year + "/" + month + "/" + day;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ticket other = (Ticket) obj;
        if (this.ID != other.ID) {
            return false;
        }
        if (this.seatNumber != other.seatNumber) {
            return false;
        }
        if (this.trip_trainID != other.trip_trainID) {
            return false;
        }
        if (this.passengerID != other.passengerID) {
            return false;
        }
        if (this.userID != other.userID) {
            return false;
        }
        if (this.day != other.day) {
            return false;
        }
        if (this.month != other.month) {
            return false;
        }
        if (this.year != other.year) {
            return false;
        }
        return true;
    }

    public void SaveToDB() throws SQLException, ClassNotFoundException {
        DataBase.Booking(this);
    }

    @Override
    public String toString() {
        return "Ticket{" + "ID=" + ID + ", seatNumber=" + seatNumber + ", trip_trainID=" + trip_trainID + ", passengerID=" + passengerID + ", userID=" + userID + ", date=" + getDate_() + '}';
    }

}
